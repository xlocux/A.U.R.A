# A.U.R.A Drop-in Delta: Protocol-aware proxy routing for recon tools

## Diagnosis

The attached run logs show repeated `dnsx` and `httpx` timeouts after A.U.R.A selected proxies that only passed TCP reachability checks. Several selected endpoints used ports commonly associated with SOCKS proxies while being treated as HTTP proxies. A TCP-only preflight can therefore mark a listener as usable even when it cannot complete the proxy protocol handshake required by the recon tool.

A second issue was route policy: DNS resolver tools were forced through generic HTTP/SOCKS proxy environment variables even though they do not reliably proxy UDP/TCP DNS lookups. That can stall `dnsx` regardless of proxy rotation.

## Fix

- Added `src/recon/tool-proxy-policy.js` as the central per-tool proxy routing policy.
- Kept DNS resolver tools (`dnsx`, `puredns`, `shuffle-dns`) direct instead of forcing generic proxy env vars.
- Routed `httpx` through its native `-proxy` flag instead of relying on environment-only behavior.
- Upgraded proxy preflight from TCP-only to protocol-aware checks:
  - HTTP/HTTPS proxies must answer an HTTP CONNECT check.
  - SOCKS4/SOCKS5 proxies must complete the corresponding connect handshake.
- Kept the existing AI-aware rotation/recovery architecture, but made it respect per-tool proxy policy.
- Redacted proxy credentials in displayed command strings.
- Improved proxy source port inference for common SOCKS port `4145`.
- Updated tests and documentation.

## Validation

Executed successfully:

```bash
node --check src/recon/linux-tools.js
node --check src/recon/proxy-preflight.js
node --check src/recon/proxy-rotation.js
node --check src/recon/recon-engine.js
node --check src/recon/tool-runners.js
node --check src/recon/proxy-sources.js
node --check src/recon/technology-detectors.js
node --check src/recon/tool-proxy-policy.js
node --check tests/proxy-system.test.js
npm test
```

Test result: `70/70` passing.

## Drop-in usage

Copy the files in this zip over the repository root, then run:

```bash
npm test
```
